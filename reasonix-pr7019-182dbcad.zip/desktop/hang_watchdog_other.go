//go:build !darwin && !windows

package main

func mainThreadWatchdogSupported() bool {
	return false
}

func startNativeMainThreadHeartbeat(uint64) {}

func stopNativeMainThreadHeartbeat() {}
